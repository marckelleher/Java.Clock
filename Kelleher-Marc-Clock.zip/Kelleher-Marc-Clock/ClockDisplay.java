
/**
 * The ClockDisplay class implements a digital clock display for a
 * European-style 24 hour clock. The clock shows hours and minutes. The 
 * range of the clock is 00:00 (midnight) to 23:59 (one minute before 
 * midnight).
 * 
 * The clock display receives "ticks" (via the timeTick method) every minute
 * and reacts by incrementing the display. This is done in the usual clock
 * fashion: the hour increments when the minutes roll over to zero.
 * 
 * @author Michael Kölling and David J. Barnes
 * @version 2011.07.31
 * 
 * Modifications:
 * @author Marc Kelleher 7/26/15
 * Description:  Changes made to make this program work on a 12-hour clock.
 * Changes made to:  timeTick method, setTime method and ClockDisplay constructors.
 */
public class ClockDisplay
{
    private NumberDisplay hours;
    private NumberDisplay minutes;
    private String displayString;    // simulates the actual display
    
    /**
     * Constructor for ClockDisplay objects. This constructor 
     * creates a new clock set at 00:00.
     * Modifications:
     * @author Marc Kelleher 7/26/15
     * Description:  Changes made to the parameters to make this method work on a 12-hour clock.
     */
    public ClockDisplay()
    {
        hours = new NumberDisplay(13);
        minutes = new NumberDisplay(60);
        updateDisplay();
    }

    /**
     * Constructor for ClockDisplay objects. This constructor
     * creates a new clock set at the time specified by the 
     * parameters.
     * Modifications:
     * @author Marc Kelleher 7/26/15
     * Description:  Changes made to make this method work on a 12-hour clock.
     * Invalid times will receive an error and military times will be automatically adjusted.
     */
    public ClockDisplay(int hour, int minute)
    {
        if(hour < 1 || hour > 23 || minute < 0 || minute > 59)
        {  // Invalid time parameters given 
            System.out.println("Not a valid time, clock will be set to 12:00.");
            hour = 12;
            minute = 00;
            hours = new NumberDisplay(13);
            minutes = new NumberDisplay(60);
            setTime(hour, minute);
        }
        else if (hour > 12)
        {  // Adjustment to make 24 hour time to 12 hour
            hour = hour - 12;
            hours = new NumberDisplay(13);
            minutes = new NumberDisplay(60);
            setTime(hour, minute);
        }
        else
        {
            hours = new NumberDisplay(13);
            minutes = new NumberDisplay(60);
            setTime(hour, minute);
        }
    }

    /**
     * This method should get called once every minute - it makes
     * the clock display go one minute forward.
     * Modifications:
     * @author Marc Kelleher 7/26/15
     * Description:  Changes made to make this method work on a 12-hour clock.
     * Clock will not tick until a valid time is entered and hours will rollover to 1 after 12.
     */
    public void timeTick()
    {
        if(hours.getValue() == 0)
        {
            System.out.println("You must enter a valid time first.");
        }
        else
        {
            minutes.increment();
            if(minutes.getValue() == 0) 
            {  // The minutes just rolled over!
            if(hours.getValue() == 12)
            {  // The hours just rolled over!
                hours.setValue(1);
            }
            else
            {
                hours.increment();
            }
            }
            updateDisplay();
        }
    }

    /**
     * Set the time of the display to the specified hour and
     * minute.
     * Modifications:
     * @author Marc Kelleher 7/26/15
     * Description:  Changes made to make this method work on a 12-hour clock.
     * Restrictions set for parameters to provide accurate time measurements.
     * Military time will automatically be adjusted to 12 hour.
     */
    public void setTime(int hour, int minute)
    {
        if(hour < 1 || hour > 23 || minute < 0 || minute > 59)
        {  // Invalid time parameters given 
            System.out.println("Please enter a valid time.");
        }
        else if(hour > 12)
        {  // Adjustment to make 24 hour time to 12 hour
            hour = hour - 12;
            hours.setValue(hour);
            minutes.setValue(minute);
            updateDisplay();
        }
        else
        {
            hours.setValue(hour);
            minutes.setValue(minute);
            updateDisplay();
        }
    }

    /**
     * Return the current time of this display in the format HH:MM.
     */
    public String getTime()
    {
        return displayString;
    }
    
    /**
     * Update the internal string that represents the display.
     */
    private void updateDisplay()
    {
        displayString = hours.getDisplayValue() + ":" + 
                        minutes.getDisplayValue();
    }
}
